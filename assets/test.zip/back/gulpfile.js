'use strict';

var postcss  = require('gulp-postcss'),
gulp         = require('gulp'),
autoprefixer = require('autoprefixer'),
cssgrace     = require('cssgrace'),
plumber      = require('gulp-plumber'),
csswring     = require('csswring'),
csscomb      = require('gulp-csscomb'),
sourcemaps   = require('gulp-sourcemaps'),
rename       = require('gulp-rename'),
compass      = require('gulp-compass'),
minifyCSS    = require('gulp-minify-css');


// gulp.task('mystyle', function () {
//     var processors = [
//         cssgrace
//         // cssgrace,
//         // autoprefixer({browsers: ['last 1 version']}),
//         // csswring
//     ];
//     return gulp.src( ['./assets/css/all.css'] )
//         // .pipe( plumber() )
//         // .pipe(sourcemaps.init())
//         .pipe( postcss( [cssgrace] ) )
//         // .pipe( sourcemaps.write("."))
//         .pipe( rename({ extname: '.min.js' }) )
//         .pipe( gulp.dest('built') )

// });


gulp.task('watch', function () {
  gulp.watch(['./assets/**/all.css'], ['mystyle']);
  // gulp.watch(['./assets/**/all.scss','!./assets/**/*.min.*'], ['compass']);
});

gulp.task('mystyle', function () {
    var processors = [
        autoprefixer({browsers: ['last 1 version']}),
        require('cssgrace'),
        require('csswring')
    ];
    return gulp.src( ['./assets/**/all.css'] )
    .pipe(plumber({
      errorHandler: function (error) {
        console.log(error.message);
        this.emit('end');
    }}))
    .pipe( csscomb() )
    // .pipe( rename({ extname: '.comb.css' }) )
    // .pipe( gulp.dest('./assets') )
    .pipe( postcss( processors ) )
    .pipe( rename({ extname: '.min.css' }) )
    // .pipe( rename('all.min.css') )
    .pipe( gulp.dest('./assets') )
});

gulp.task('compass', function() {

  gulp.src('./assest/*.scss')
    .pipe(compass({
        config_file: './config.rb',
        css: 'assets/css',
        sass: 'assets/sass'
    }))
    .pipe( gulp.dest('./assets') )
});

// gulp.task('compass', function() {
//   var processors = [
//     require('cssgrace')
//   ];

//   gulp.src('./assets/*.scss')
//     .pipe(compass({
//       config_file: './config.rb',
//       css: './assets/css',
//       sass: './assets/sass'
//     }))
//     .pipe( postcss( processors ) )
//     .pipe( rename ({ extname: '.min.js' }) )
//     .pipe(gulp.dest('./app/assets'));
// });


// var gulp = require('gulp');
// var rename = require('gulp-rename');
// var postcss = require('gulp-postcss');
// var cssgrace = require('cssgrace');
// var notify = require('gulp-notify');
// // var autoprefixer = require('autoprefixer-core')

// var fs = require('fs');
// var path    = require('path');

// gulp.task('test', function () {
//     var processors = [
//         require('cssgrace')
//     ];

//     // gulp.src('src/all.css')
//     //     .pipe(postcss(processors))
//     //     // .pipe( notify({ message: 'Styles task complete' }))
//     //     .pipe(rename('gulp.css'))
//     //     .pipe(gulp.dest('build'))

//     return gulp.src( ['./assets/**/all.css'] )
//         .pipe( postcss( [ cssgrace ] ) )
//         .pipe( rename({ extname: '.min.js' }) )
//         .pipe( gulp.dest('./assets/css') )

// });

// gulp.task('watch', function () {
//   gulp.watch('src/*.css', ['default']);
// });


